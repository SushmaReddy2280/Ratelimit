package com.gemini.api;

import java.time.LocalTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GeminiController {

	@Autowired
	private GeminiService geminiService;
	
	@Value("${gemini.api.key}")
	private String gemini_api_key;  
	
	//private final Bucket bucket = null;
	
	/*public GeminiController() {
        Bandwidth limit = Bandwidth.classic(600, Refill.greedy(600, Duration.ofMinutes(1)));
        this.bucket = Bucket4j.builder()
            .addLimit(limit)
            .build();
	}*/

	/*@GetMapping(value = "/v1/symbols")
    public ResponseEntity<String> createBroker() throws Exception {
		if (bucket.tryConsume(1)) {
			String response = geminiService.createNewBroker();
			String responseUsingWebClient = geminiService.createNewBrokerWithWebClient();
			System.out.println("### responseUsingWebClient "+responseUsingWebClient);
	        return ResponseEntity.ok(response);
		}
        return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
    }*/
	//@Async
	@GetMapping(value = "/v1/symbols")
    public ResponseEntity<String> createBrokerBulk() throws Exception {
		Long currentAvailbleRequests = 0l;
		System.out.println("start "+new Date());
		/*
		for (int i=0; i<=3; i=i+1) {
			
			try {
			  geminiService.createNewBroker();
			  System.out.println("currentAvailbleRequests="+currentAvailbleRequests);
			  System.out.println("end i"+i);				
			  System.out.println("start Time"+i+"="+LocalTime.now());
				
			}
				catch (Exception exception)  {
					throw new Exception("Exception while fetching data from Gemini. Message: \"+exception.getMessage()");
					//exception.printStackTrace();
				}
					// TODO Auto-generated catch block
					
				System.out.println("end Time"+i+"="+LocalTime.now());
			}
		*/
        return ResponseEntity.ok("Done");
    
}}
