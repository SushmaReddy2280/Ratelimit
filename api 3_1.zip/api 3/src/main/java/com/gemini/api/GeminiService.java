package com.gemini.api;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.digest.HmacAlgorithms;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class GeminiService {
	
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	private HashOperations<String, String, String> hashOperations;
	
	@Autowired
	private CacheManager simpleCacheManager;
    //private final CacheManager caffeineCacheManager;    


	private HashMap<String, String> hashOperations1 = new HashMap<String, String>();

	@Value("${gemini.rate.limit.requests.per.minute}")
	private String rateLimitRequestsPerMinute;
	
	
	long rateLimit=600;

	@PostConstruct
	private void init() {
	    hashOperations = stringRedisTemplate.opsForHash();
	}

	private String api_key ="account-JrJD7QEqdcvrzg4cVX9v";// "master-xRyg1I5HG4sZSLCGC1Si";//"account-EP1eYoOzEmWPTPnd4Qrk";
	private String api_secret = "JujngdUzmxFf12Pqk1ujZihymGn";//"4cJgbEiME9dmYferpF4KDSoUxnE";//"43SoBBdTE4VSUmFHrAMJwg5cyipw";

	private final String COUNT = "count";


	@Async
	public String createNewBroker() throws Exception{

		setRateLimt(10);
		Map<String , Integer> cacheTest= (Map<String, Integer>) simpleCacheManager.getCache("rateLimit");
		System.out.println("Test="+cacheTest.get("rateLimit"));
		
		String response = "";
		try {
	    	HttpHeaders headers = getHttpHeaders();
	    	HttpEntity<GeminiNewBrokerorderRequest> requestEntity = new HttpEntity<>(headers);
	    	//response = "success";
	    	response = restTemplate.exchange("https://api.gemini.com/v1/symbols", HttpMethod.GET, requestEntity, String.class).getBody();
	    	System.out.println("### response "+response);
	    	//Thread.sleep(1000);
		} catch (Exception exception) {
			throw new Exception ("Exception while fetching data from Gemini. Message: "+exception.getMessage());
			//exception.printStackTrace();
		}
		return response;
	}
	
	@Cacheable(cacheNames = "rateLimit")
	public Map<String, Integer> setRateLimt(int ratelimit){
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("rateLimit", Integer.valueOf(ratelimit));
		return map;		
	}

      
	/*public String createNewBrokerWithWebClient() throws Exception {

		if (!isRequestAllowed("gemini:"+api_key)) {
			return "Rate Limit Reached. Request not processed.";
		}

		int nonce = Integer.parseInt(String.valueOf(new Date().getTime()).substring(4));
		Random random = new Random(); 
    	GeminiNewBrokerorderRequest gmbr = new GeminiNewBrokerorderRequest("/v1/clearing/broker/new", nonce, "R485E04Q","Z4929ZDY",
    			"ethusd", String.valueOf(random.nextDouble()), 1.0, String.valueOf(Math.abs(random.nextInt())),"sell");
    	String requestBodyString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(gmbr);
    	System.out.println("###### requestBodyString "+requestBodyString);
    	String encodedPayloadString = Base64.getEncoder().encodeToString(requestBodyString.getBytes());
    	String workingSig = new HmacUtils(HmacAlgorithms.HMAC_SHA_384, api_secret).hmacHex(encodedPayloadString);
    	//System.out.println("##### working Signature "+workingSig);

    	String responseString = "";
		WebClient.RequestHeadersSpec<?> headersSpec = WebClient.builder().baseUrl("https://api.sandbox.gemini.com")
				.defaultHeader(HttpHeaders.CACHE_CONTROL, "no-cache")
				.defaultHeader(HttpHeaders.CONTENT_LENGTH, "0")
				.build().post().uri("/v1/clearing/broker/new")
				.bodyValue(BodyInserters.fromValue(""))
				.header("X-GEMINI-APIKEY", api_key)
				.header("X-GEMINI-PAYLOAD", encodedPayloadString)
				.header("X-GEMINI-SIGNATURE", workingSig);
		
		Mono<String> responseMono = headersSpec.exchangeToMono(response -> handleClientResponse(response));
		responseString = responseMono.block();
		return responseString;
	}
	public HttpClient getHttpClient() {
		return HttpClient.create().secure()
				.proxy(proxyOptions -> proxyOptions.type(ProxyProvider.Proxy.HTTP)
						                           .host("proxy.statestr.com")
						                           .port(80)
						                           .build());
	}

	public Mono<String> handleClientResponse(ClientResponse clientResponse) {
		if (clientResponse.statusCode().is2xxSuccessful()) {
			return clientResponse.bodyToMono(String.class);
		} else if (clientResponse.statusCode().is4xxClientError()) {
			return Mono.just(String.format("Error response %s, %s",
					clientResponse.statusCode(), clientResponse.bodyToMono(String.class)));
		} else {
			return clientResponse.createException().flatMap(Mono::error);
		}
	}*/


	/*public Boolean getCurrentAvailbleRequests(String key) {
		   // Boolean hasKey = stringRedisTemplate.hasKey(key);
		   // hashOperations = .opsForHash();
		    if (StringUtils.isEmpty(key)) {
		        Long value = Long.valueOf(hashOperations1.get(key));
		        hashOperations1.put(key, value-1+"");
		        //log.info("Current value for key "+key+" is "+value);
		        return true;
		    } else {
		        hashOperations1.put(key, rateLimitRequestsPerMinute);
		       // stringRedisTemplate.expire(key, 1, TimeUnit.MINUTES);
		    }
		    
		    return true ;
		}*/

	private HttpHeaders getHttpHeaders() throws Exception {
		int nonce = Integer.parseInt(String.valueOf(new Date().getTime()).substring(4));
		//int nonce = Integer.MAX_VALUE;
		Random random = new Random(); 
    	GeminiNewBrokerorderRequest gmbr = new GeminiNewBrokerorderRequest("/v1/clearing/broker/new", nonce, "R485E04Q","Z4929ZDY",
    			"ethusd", String.valueOf(random.nextDouble()), 1.0, String.valueOf(Math.abs(random.nextInt())),"sell");
    	String requestBodyString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(gmbr);
    	//System.out.println("###### requestBodyString "+requestBodyString);
    	String encodedPayloadString = Base64.getEncoder().encodeToString(requestBodyString.getBytes());
    	//System.out.println("###### encodedPayloadString "+encodedPayloadString);
    	String workingSig = new HmacUtils(HmacAlgorithms.HMAC_SHA_384, api_secret).hmacHex(encodedPayloadString);
    	//System.out.println("##### working Signature "+workingSig);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "text/plain");
		/*headers.add("Content-Length", "0");
		headers.add("X-GEMINI-APIKEY", api_key);
		headers.add("X-GEMINI-PAYLOAD", encodedPayloadString);
		headers.add("X-GEMINI-SIGNATURE", workingSig);
		headers.add("Cache-Control", "no-cache");*/
		return headers;
	}
}
