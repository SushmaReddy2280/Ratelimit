# gemini
Redis and bucketJ to take care of rate limit and use gemini API's using Java reactive API(Web Clients)
