package com.statestreet.ratelimit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatelimitApplicationTests {

	@Test
	void contextLoads() {
	}

}
