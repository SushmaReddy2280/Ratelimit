package com.statestreet.ratelimit.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

@RunWith(SpringJUnit4ClassRunner.class)
public class RatelimitServiceTest {
	
	@InjectMocks
	RateLimitService rateLimitService;
	
	@Mock
	StringRedisTemplate stringRedisTemplate = new StringRedisTemplate();
	
	@MockBean
	HashOperations hashOperations;
	
	@Before
	public void Setup() {
		hashOperations = Mockito.mock(HashOperations.class);
	}
	
	@Test
	public void testCurrentAvilableRequests() {
		doReturn(hashOperations).when(stringRedisTemplate).opsForHash();
		ReflectionTestUtils.setField(rateLimitService, "rateLimitRequestsPerMinute", "600");
		
		long avilableRequests = rateLimitService.getCurrentAvailbleRequests("test-api-key");
		assertEquals(avilableRequests, 600);
	}
}
