package com.statestreet.ratelimit.util;

public class Constants {
	public static String COUNT = "count";
	public static String REMOTE = "remote";
	public static String LOCAL = "local";
}
