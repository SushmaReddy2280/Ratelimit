package com.gemini.demo;

public class Constants {
	static String COUNT = "count";
}
